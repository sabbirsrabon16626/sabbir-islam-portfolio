SABBiR ISLAM — PERSONAL PORTFOLIO
================================

FOLDER NAME
sabbir-islam-portfolio

OPEN THE WEBSITE
1. Extract the ZIP file.
2. Open the sabbir-islam-portfolio folder.
3. Double-click index.html to open the home page in a browser.
4. Use the navigation menu to visit the other pages.

EDIT THE WEBSITE
Open the folder in Visual Studio Code or another text editor. The pages are
plain HTML and the shared design is in css/style.css. Keep the images and files
folders in place so the photo and CV links continue to work.

PAGES
- index.html       Home
- about.html       About
- education.html   Education
- skills.html      Skills
- projects.html    Projects and learning
- experience.html  Experience and leadership
- achievements.html Achievements
- cv.html          CV
- contact.html     Contact details and social links

ASSETS
- images/profile.jpg  Profile photo
- files/my-cv.pdf     CV PDF

BEFORE PUBLISHING
The site includes contact details and a downloadable CV. Check that you are
comfortable making your phone number, address, and any references in the CV
publicly accessible before uploading the site to the internet.

The projects page describes the portfolio and skill areas without claiming
undocumented completed projects. Add links or screenshots only for work you
can show and explain. Review the content periodically so it remains accurate.

This is a static website and does not require installation or a server to open
locally. External social links open the relevant social profiles.
